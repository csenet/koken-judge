import { Docker } from 'node-docker-api';
import { ContainerManager } from './ContainerManager';

const docker: Docker = new Docker({ socketPath: '/var/run/docker.sock' });


async function main() {
  const container = new ContainerManager(docker, 'ubuntu');
  await container.createContainer('ubuntu');
  console.log(await container.putFile('test', '/judge/'));
  console.log(await container.execCommandOutput(['ls','-al']));
  await container.removeContainer();
}

(async () => {
  await main();
})();
